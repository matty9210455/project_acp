#!/bin/bash
make -f St