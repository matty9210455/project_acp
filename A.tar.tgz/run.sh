#!/bin/bash
./serial