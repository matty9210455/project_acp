#!/bin/bash
g++ -std=c++11 main.cpp read.cpp write_update.cpp -I. -o serial