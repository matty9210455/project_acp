#!/bin/bash
./omp