#!/bin/bash
mpic++ main.cpp read.cpp write_update.cpp -I. -o mpi