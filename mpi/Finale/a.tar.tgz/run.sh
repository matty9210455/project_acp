#!/bin/bash
mpirun -n 4 mpi